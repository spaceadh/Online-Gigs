% Load Dataset
data = readtable('BP(1).xlsx');

% Display variable names
disp(data.Properties.VariableNames);

% Extract Tables
inputs1 = data.Var1;  
inputs2 = data.Var2;  
outputs = data.Var3;  

% Data Preprocessing
inputs1 = zscore(inputs1);
inputs2 = zscore(inputs2);
disp('Data Preprocessing completed.');

% Combine Inputs
inputs_combined = [inputs1, inputs2];
disp('Combining Inputs completed.');

% Split the Dataset
[trainInd, valInd, testInd] = dividerand(size(inputs_combined, 1), 0.7, 0.15, 0.15);

inputs_train = inputs_combined(trainInd, :);
outputs_train = outputs(trainInd, :);

inputs_val = inputs_combined(valInd, :);
outputs_val = outputs(valInd, :);

inputs_test = inputs_combined(testInd, :);
outputs_test = outputs(testInd, :);
disp('Splitting Datasets completed.');

% Neural Network Model
hidden_layer_sizes = [10, 5];
net = feedforwardnet(hidden_layer_sizes);

disp('Training model is successful.');  % Added success message

% Train the Neural Network
net.trainParam.epochs = 100; % Adjust as needed
net.trainParam.lr = 0.01; % Adjust learning rate or other hyperparameters
[net, tr] = train(net, inputs_train', outputs_train', 'useParallel', 'yes', 'showResources', 'yes');

% Display contents of tr
disp('Training Progress Information:');
disp(['Number of Epochs: ', num2str(net.trainParam.epochs)]);
disp(['Learning Rate: ', num2str(net.trainParam.lr)]);
disp(['Training Time: ', num2str(tr.time(end)), ' seconds']);
disp(['Final Training Performance: ', num2str(tr.perf(end))]);
disp(['Final Validation Performance: ', num2str(tr.vperf(end))]);

% Visualization - Plot Training Progress
figure;

% Check if 'perf' and 'vperf' fields exist in tr
if isfield(tr, 'perf') && isfield(tr, 'vperf')
    % Display a warning if 'perf' or 'vperf' is not numeric
    if ~isnumeric(tr.perf) || ~isnumeric(tr.vperf)
        disp('Warning: Unexpected data type in tr.perf or tr.vperf');
    else
        % Plot training progress
        epochs = 1:numel(tr.perf);
        plot(epochs, tr.perf, '-b', 'DisplayName', 'Training Loss');
        hold on;
        plot(epochs, tr.vperf, '-r', 'DisplayName', 'Validation Loss');

        legend('show');
        xlabel('Epochs');
        ylabel('Loss');
        title('Training Progress');
    end
else
    disp('Error: Missing fields in tr');
end

% Display Final Training and Validation Losses
final_training_loss = tr.perf(end);
final_validation_loss = tr.vperf(end);

disp(['Final Training Loss: ', num2str(final_training_loss)]);
disp(['Final Validation Loss: ', num2str(final_validation_loss)]);

% Plotting predictions and losses
figure;

% Check if 'perf' and 'vperf' fields exist in tr
if isfield(tr, 'perf') && isfield(tr, 'vperf')
    % Display a warning if 'perf' or 'vperf' is not numeric
    if ~isnumeric(tr.perf) || ~isnumeric(tr.vperf)
        disp('Warning: Unexpected data type in tr.perf or tr.vperf');
    else
        % Plot training progress
        epochs = 1:numel(tr.perf);
        plot(epochs, tr.perf, '-b', 'DisplayName', 'Training Loss');
        hold on;
        plot(epochs, tr.vperf, '-r', 'DisplayName', 'Validation Loss');

        % Plot final losses
        scatter(length(tr.perf), final_training_loss, 100, 'g', 'filled', 'DisplayName', 'Final Training Loss');
        scatter(length(tr.vperf), final_validation_loss, 100, 'm', 'filled', 'DisplayName', 'Final Validation Loss');

        legend('show');
        xlabel('Epochs');
        ylabel('Loss');
        title('Training Progress');
    end
else
    disp('Error: Missing fields in tr');
end

% Evaluate on Test Set
predictions_test = net(inputs_test');
mse_test = mean((predictions_test - outputs_test').^2);

disp(['Mean Squared Error on Test Set: ', num2str(mse_test)]);

% Save the Trained Model
save('final_trained_model.mat', 'net');
disp('Trained model saved successfully.');

% Load the Model
loaded_net = load('final_trained_model.mat');
final_net = loaded_net.net;

% Load or Generate New Data
% Use the original testing inputs as new data for testing
new_data = inputs_test;

% Testing on New Data
new_predictions = final_net(new_data')';

disp('Predictions on new data:');
disp(new_predictions);

% Visualization - Plot New Data Predictions
figure;

% Assume you have ground truth values for new data (replace 'ground_truth' with your actual variable)
% As we don't have ground truth, skip plotting it

% Plotting predictions only
plot(1:length(new_predictions), new_predictions, '-b', 'DisplayName', 'Predictions');

legend('show');
xlabel('Data Points');
ylabel('Values');
title('Predictions on New Data');

% Display Mean Squared Error on New Data (not meaningful without ground truth)
disp('Mean Squared Error on New Data: Not applicable without ground truth');